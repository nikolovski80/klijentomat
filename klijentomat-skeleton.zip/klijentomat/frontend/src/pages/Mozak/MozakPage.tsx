export default function MozakPage() {
  return (
    <div className="p-8">
      <div className="text-lg font-semibold mb-2">🧠 Mozak Firme</div>
      <div className="text-sm text-slate-500 mb-6">Baza znanja — cenovnik, katalog, branding, FAQ</div>
      <div className="bg-panel border border-slate-800 rounded-xl p-6">
        <div className="text-xs text-slate-600">Sprint S1 — u izgradnji</div>
      </div>
    </div>
  )
}
