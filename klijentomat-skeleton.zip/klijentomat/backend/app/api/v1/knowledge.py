from fastapi import APIRouter, Depends
from app.core.deps import get_current_tenant
from app.models.__init__ import Tenant

router = APIRouter()


@router.get("/")
async def get_knowledge(tenant: Tenant = Depends(get_current_tenant)):
    # S1-01: implementirati CRUD po kategorijama
    return {"categories": {}}


@router.put("/{category}")
async def update_knowledge(category: str, tenant: Tenant = Depends(get_current_tenant)):
    # S1-01: update kategorije
    return {"status": "ok", "category": category}
